package com.example.dimas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
